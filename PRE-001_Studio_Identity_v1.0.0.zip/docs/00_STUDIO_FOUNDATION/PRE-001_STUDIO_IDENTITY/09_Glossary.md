# Glossary

-   **AISOS/ASOS:** Internal AI studio operating system.
-   **Canon:** Approved, authoritative project information.
-   **Module:** A related collection of Markdown documents.
-   **SSOT:** Single Source of Truth.
