# Studio Personality

Thoughtful • Cinematic • Ambitious • Disciplined • Collaborative •
Innovative
