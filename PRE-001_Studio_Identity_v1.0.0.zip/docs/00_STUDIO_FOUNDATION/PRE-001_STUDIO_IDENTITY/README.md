# PRE-001 --- Studio Identity

**Document ID:** PRE-001\
**Version:** v1.0.0\
**Status:** Canonical Draft

## Purpose

This module establishes the identity, philosophy, and long-term
direction of the studio. Every future production inherits these
principles.

## Contents

-   00_Cover.md
-   01_Studio_Name.md
-   02_Vision.md
-   03_Mission.md
-   04_Core_Values.md
-   05_Creative_Manifesto.md
-   06_Studio_Personality.md
-   07_Brand_Principles.md
-   08_Long_Term_Ambition.md
-   09_Glossary.md
