# Studio Name (Working)

**Working Internal Name:** Aetherion Studio Operating System (ASOS)

> Placeholder until a permanent studio brand is selected. This name
> refers to the internal operating system, not necessarily the public
> studio brand.
