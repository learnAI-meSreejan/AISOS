# Long-Term Ambition

Build a reusable studio operating system capable of supporting multiple
franchises, films, games, and interactive experiences over many years.
