# Core Values

1.  Story before spectacle.
2.  Character before plot.
3.  Consistency before speed.
4.  Curiosity with discipline.
5.  Respect for inspiration without imitation.
6.  Continuous improvement.
