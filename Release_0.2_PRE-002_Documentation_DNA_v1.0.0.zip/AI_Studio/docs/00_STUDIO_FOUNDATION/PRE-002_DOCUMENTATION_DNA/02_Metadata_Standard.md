# Metadata Standard
```yaml
Document_ID:
Title:
Version:
Status:
Owner:
Parent:
Children:
Dependencies:
Tags:
```
