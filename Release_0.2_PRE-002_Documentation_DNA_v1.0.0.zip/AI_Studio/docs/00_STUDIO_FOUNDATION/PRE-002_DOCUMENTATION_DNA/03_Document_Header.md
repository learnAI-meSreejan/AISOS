# Document Header
Standard title + metadata + purpose.
