# Markdown Style Guide
Use GitHub Flavored Markdown.
