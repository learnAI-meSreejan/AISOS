# Definition of Done
Metadata complete, QA passed.
