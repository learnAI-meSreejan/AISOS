# Examples
Good vs bad document examples.
