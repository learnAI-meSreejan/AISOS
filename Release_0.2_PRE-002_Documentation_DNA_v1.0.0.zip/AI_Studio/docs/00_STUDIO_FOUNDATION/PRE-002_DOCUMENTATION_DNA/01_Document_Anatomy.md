# Document Anatomy
Metadata
Purpose
Scope
Dependencies
Content
Examples
Revision History
