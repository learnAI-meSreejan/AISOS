# Lifecycle
Draft→Review→Approved→Canonical→Archived
