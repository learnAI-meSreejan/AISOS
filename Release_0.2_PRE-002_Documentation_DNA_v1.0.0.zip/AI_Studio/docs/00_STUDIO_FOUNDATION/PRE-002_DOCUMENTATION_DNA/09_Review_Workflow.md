# Review Workflow
Validate metadata, canon, links, changelog.
