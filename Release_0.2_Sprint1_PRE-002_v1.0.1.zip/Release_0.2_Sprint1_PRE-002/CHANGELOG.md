# Changelog

## v1.0.1
- Started Sprint 1.
- Added module overview.
- Defined canonical document anatomy.
