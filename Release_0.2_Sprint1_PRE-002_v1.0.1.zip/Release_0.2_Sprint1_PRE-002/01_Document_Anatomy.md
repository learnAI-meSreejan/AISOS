# Document Anatomy

Every canonical document SHALL contain:

1. Metadata
2. Purpose
3. Scope
4. Audience
5. Authority Level
6. Dependencies
7. Related Documents
8. Main Content
9. Examples (when applicable)
10. Review Checklist
11. Changelog

## Metadata Example

```yaml
Document_ID: PRE-002
Version: 1.0.1
Status: Draft
Authority: Foundation
Owner: Documentation Team
```

## Rules
- One topic per document.
- Stable headings.
- Relative links only.
- GitHub Flavored Markdown.
