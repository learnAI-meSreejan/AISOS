# Module Overview

## Purpose
PRE-002 defines the documentation rules for the entire repository.

## Scope
Applies to every Markdown document.

## Objectives
- Consistent formatting
- AI compatibility
- Human readability
- Long-term maintainability

## Authority
Foundation Module. Child modules inherit these standards.

## Related
- PRE-001 Studio Identity
- ROOT-001 Studio Constitution (planned)
